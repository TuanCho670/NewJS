mkdir -p layout/var/jb/Library
mv layout/Library/PreferenceLoader layout/var/jb/Library/
rm -rf layout/Library